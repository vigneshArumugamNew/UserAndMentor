from django.apps import AppConfig


class MentorappConfig(AppConfig):
    name = 'MentorApp'
