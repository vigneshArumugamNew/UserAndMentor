from django import forms
from .models import queriesTable

class userQueryForm(forms.ModelForm):
    class Meta:
        model = queriesTable
        fields = ('queries','uploadFile')