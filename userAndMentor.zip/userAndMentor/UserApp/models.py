from django.db import models


class queriesTable(models.Model):
    queriesTableId = models.AutoField(primary_key=True)
    queries = models.TextField(max_length=255,null=True)
    uploadFile = models.FileField(upload_to='queriesDoc/')
    createdDateTime = models.DateTimeField(auto_now_add=True)
    updatedDateTime = models.DateTimeField(auto_now=True)

    def __int__(self):
        return self.queriesTableId

    class Meta:
        db_table = 'queriesTable'


class notification(models.Model):
    notificationId = models.AutoField(primary_key=True)
    userId = models.CharField(max_length=255,null=True)
    mentorId = models.CharField(max_length=255,null=True)
    desc = models.CharField(max_length=255,null=True)
    type = models.CharField(max_length=255,null=True)
    href = models.CharField(max_length=255,null=True)
    viewed = models.CharField(max_length=255, default='No', editable=False)
    status = models.CharField(max_length=50,default='Active')
    createdDateTime = models.DateTimeField(auto_now_add=True)
    updatedDateTime = models.DateTimeField(auto_now=True)

    def __int__(self):
        return self.notificationId

    class Meta:
        db_table = 'notification'

    
class mentorMessages(models.Model):
    messageId = models.AutoField(primary_key=True)
    messages = models.TextField(max_length=255,null=True)
    createdDateTime = models.DateTimeField(auto_now_add=True)
    updatedDateTime = models.DateTimeField(auto_now=True)

    def __int__(self):
        return self.messageId

    class Meta:
        db_table = 'mentorMessages'