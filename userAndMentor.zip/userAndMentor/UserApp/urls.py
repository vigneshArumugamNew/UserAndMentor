from django.contrib import admin
from django.urls import path
from .import views
from rest_framework.urlpatterns import format_suffix_patterns

urlpatterns = [
   path('getmentorDataClass/',views.getmentorDataClass.as_view()),
   path('userQrySave/',views.userQrySave,name='userQrySave'),
   
]

