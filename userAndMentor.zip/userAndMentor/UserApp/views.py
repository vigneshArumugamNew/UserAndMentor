from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.views.decorators.csrf import csrf_exempt
import json
from django.http import  HttpResponseRedirect, JsonResponse,HttpResponse
from UserMentorApp.serializers import *
from .models import *
from django.db import connection
import uuid
from UserMentorApp import utility
import zerosms
from django.core.mail import EmailMessage
from django.template.loader import render_to_string
import random
import os
from django.conf import settings
from django.views.decorators.cache import cache_control
import urllib.parse
import base64
import collections
from .forms import *
from UserMentorApp.forms import *
# Create your views here.


class getmentorDataClass(APIView):
    def get(self, request, format=None):
        mentorData = mentorRegTable.objects.all()
        serializer = mentorRegSerializer(mentorData, many=True)
        return Response(serializer.data)

@csrf_exempt
def userQrySave(request):
    currentSchema = connection.schema_name
    connection.set_schema(schema_name=currentSchema)
    userEmail = request.POST.get('userEmail')
    print(userEmail)
    print(request.POST)
    form = mentorQueryForm(request.POST, request.FILES)
    
    print(form)
    if form.is_valid():
        form.save()
       
        mentorEmail=mentorRegTable.objects.filter(mentorId=request.POST.get('mentorId')).values('email')
        # sendingEmail(request,'vignesh','vigneshlike007@gmail.com','mail.html')
        mentorNotification(userId=userEmail,mentorId=request.POST.get('mentorId'),desc='User send the queries',type='USQ',href='USQ').save()
        lastmQueriesTableId=mentorQueriesTable.objects.filter().values('mQueriesTableId').last()
        mentorQueriesTable.objects.filter(mQueriesTableId=lastmQueriesTableId['mQueriesTableId']).update(userId=userEmail)
        userSchema=Schema.objects.filter(schemaCompanyName=userEmail).values('schema_name')
        userSchemaName=userSchema[0]['schema_name']
        connection.set_schema(schema_name=userSchemaName)
        formm = userQueryForm(request.POST, request.FILES)
        formm.save()

        return JsonResponse({'status': 'success'})

    currentSchema = connection.schema_name
    connection.set_schema(schema_name=currentSchema)
    return JsonResponse({'status': 'success'})


def sendingEmail(request,name,email,html):
    message = render_to_string(html, {
        'name':name
    })
    mail_subject = "User send queries"
    to_email = email
    email = EmailMessage(mail_subject, message, to=[to_email])
    email.send()