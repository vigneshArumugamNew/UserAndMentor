from django.apps import AppConfig


class UsermentorappConfig(AppConfig):
    name = 'UserMentorApp'
