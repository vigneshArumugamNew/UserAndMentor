from django import forms
from .models import mentorQueriesTable

class mentorQueryForm(forms.ModelForm):
    class Meta:
        model = mentorQueriesTable
        fields = ('queries','uploadFile')