from django.db import models
from tenant_schemas.models import TenantMixin

# Create your models here.
class userRegTable(models.Model):
    userId = models.AutoField(primary_key=True)
    name=models.CharField(max_length=255,null=True)
    email=models.CharField(max_length=255,null=True)
    password=models.CharField(max_length=255,null=True)
    createdDateTime = models.DateTimeField(auto_now_add=True)
    updatedDateTime = models.DateTimeField(auto_now=True)

    def __int__(self):
        return self.userId

    class Meta:
        db_table = 'userRegTable'

    
class Schema(TenantMixin):
    schemaId = models.AutoField(primary_key=True)
    schemaCode = models.CharField(max_length=100,null=True)
    schemaDesc = models.CharField(max_length=100,null=True)
    schemaCompanyName = models.CharField(max_length=100)
    auto_create_schema = True
    createdDateTime = models.DateTimeField(auto_now_add=True)
    updatedDateTime = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'schema'


class mentorRegTable(models.Model):
    mentorId = models.AutoField(primary_key=True)
    name=models.CharField(max_length=255,null=True)
    email=models.CharField(max_length=255,null=True)
    password=models.CharField(max_length=255,null=True)
    createdDateTime = models.DateTimeField(auto_now_add=True)
    updatedDateTime = models.DateTimeField(auto_now=True)

    def __int__(self):
        return self.mentorId

    class Meta:
        db_table = 'mentorRegTable'

class mentorQueriesTable(models.Model):
    mQueriesTableId = models.AutoField(primary_key=True)
    queries = models.TextField(max_length=255,null=True)
    uploadFile = models.FileField(upload_to='queriesDoc/')
    userId = models.CharField(max_length=255,null=True)
    createdDateTime = models.DateTimeField(auto_now_add=True)
    updatedDateTime = models.DateTimeField(auto_now=True)

    def __int__(self):
        return self.mQueriesTableId

    class Meta:
        db_table = 'mentorQueriesTable'


class mentorNotification(models.Model):
    mNotificationId = models.AutoField(primary_key=True)
    userId = models.CharField(max_length=255,null=True)
    mentorId = models.CharField(max_length=255,null=True)
    desc = models.CharField(max_length=255,null=True)
    type = models.CharField(max_length=255,null=True)
    href = models.CharField(max_length=255,null=True)
    viewed = models.CharField(max_length=255, default='No', editable=False)
    status = models.CharField(max_length=50,default='Active')
    createdDateTime = models.DateTimeField(auto_now_add=True)
    updatedDateTime = models.DateTimeField(auto_now=True)

    def __int__(self):
        return self.mNotificationId

    class Meta:
        db_table = 'mentorNotification'