from rest_framework import serializers
from .models import *

class userRegSerializer(serializers.ModelSerializer):
    class Meta:
        model = userRegTable
        fields = ('userId','name','email','password')
    
class mentorRegSerializer(serializers.ModelSerializer):
    class Meta:
        model = mentorRegTable
        fields = ('mentorId','name','email','password')
    
class userQuerySerializer(serializers.ModelSerializer):
    class Meta:
        model = mentorQueriesTable
        fields = ('mQueriesTableId','queries')