from django.contrib import admin
from django.urls import path
from .import views
from rest_framework.urlpatterns import format_suffix_patterns
from django.conf import settings
from django.contrib.staticfiles.urls import static
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
urlpatterns = [
   path('',views.userLoginAndSignUp,name='empDashboard'),
   path('register',views.register,name='register'),
   path('userRegClass',views.userRegClass.as_view()),
   path('userLogin',views.userLogin.as_view()),
   path('userDashboard',views.userDashboard,name='userDashboard'),
   path('mentorLogin',views.mentorLogin.as_view()),
   path('mentorDashboard',views.mentorDashboard,name='userDashboard'),
   path('mentLoginHtml',views.mentLoginHtml,name='mentLoginHtml'),
   path('getUserQryDataClass/',views.getUserQryDataClass.as_view()),
   path('getUserQryDataClassById/',views.getUserQryDataClassById,name="getUserQryDataClassById"), 
   path('sendMsgTouser/',views.sendMsgTouser,name="sendMsgTouser"), 
   path('UserNotificationShow/',views.UserNotificationShow,name='UserNotificationShow'),
   path('MentorNotificationShow/',views.MentorNotificationShow,name='MentorNotificationShow'),
   
]
urlpatterns += staticfiles_urlpatterns()
urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)