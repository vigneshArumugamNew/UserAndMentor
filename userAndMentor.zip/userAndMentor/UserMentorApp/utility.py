import uuid,datetime,os
from django.core import serializers
from UserMentorApp.models import *
from django.db import connection
# from YTECommerce.settings import MEDIA_ROOT

def getSchemaBySchemaName(sChemaName):
    try:
        schema = Schema.objects.get(schema_name__iexact=sChemaName)
    except:
        schema = None
    return schema
