from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.views.decorators.csrf import csrf_exempt
import json
from django.http import  HttpResponseRedirect, JsonResponse,HttpResponse
from UserMentorApp.serializers import *
from .models import *
from django.db import connection
import uuid
from UserMentorApp import utility
import os
from django.conf import settings
from django.views.decorators.cache import cache_control
import urllib.parse
import base64
import collections
from UserApp.models import *

def userLoginAndSignUp(request):
    return render(request,'login.html')

def register(request):
    return render(request,'register.html')


def userDashboard(request):
    return render(request,'userDashboard.html')

# User Registration process
# @cache_control(no_cache=True, must_revalidate=True, no_store=True)
class userRegClass(APIView):
    def post(self, request, format=None):
        serializer = userRegSerializer(data=request.data)
        # serializer = userSerializer(data=request.data)
        # print(request.data['email'])
        name=request.data['name']
        email=request.data['email']
        password=request.data['password']
        if serializer.is_valid():
            # otp=otpGenerator()
            checkUser=userRegTable.objects.filter(email=email).values('email')
            if checkUser:
                # sendingEmail(request,otp,name,contactNo,email,'mail.html')
                return JsonResponse({'error': 'Exist'})
            else:
                userRegTable(name=name,email=email,password=password).save()
                tenantSchema(email)
                # sendingEmail(request,otp,name,contactNo,email,'mail.html')
                return JsonResponse({'status': 'success'})
        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        
""" create schema with auto generated schema name """
def tenantSchema(EmailCheck):
    # getting the current schema from the connection
    currentSchema = connection.schema_name
    # set the connection schema in to public
    connection.set_schema_to_public()
    # creating unique schema for the user
    name = 'ur' + uuid.uuid4().hex[:8].lower()
    # print(name)
    while True:
        # check the schema name already exists in the system
        if utility.getSchemaBySchemaName(name):
            # recreate the unique schema
            name = 'ur' + uuid.uuid4().hex[:8].lower()
            continue
        else:
            print('else')
            break
    # getting the user company name
    RegName = EmailCheck
    # print(RegName)
    # print('else vky')
    # print(name + settings.DOMAIN_NAME)
    # print(name)
    # print(RegName)
    # create tenant schema
    tenant = Schema(domain_url=name + settings.DOMAIN_NAME,
                    schema_name=name,
                    schemaCompanyName=RegName,
                    )
    tenant.save()
    # company.schemaName = name
    # company.save()
    # reset the connection to current schema
    connection.set_schema(schema_name=currentSchema)
    return name


        
# User Login process
# @cache_control(no_cache=True, must_revalidate=True, no_store=True)
class userLogin(APIView):
    def post(self, request, format=None):
        serializer = userRegSerializer(data=request.data)
        if serializer.is_valid(): 
            userData = userRegTable.objects.filter(email=request.data['email'],password=request.data['password']).values('email')
            if userData:
                return JsonResponse({'status': 'success'})
            else:
                return JsonResponse({'status': 'error'})
        return JsonResponse({'status': 'error'})

    
# Mentor Login process
# @cache_control(no_cache=True, must_revalidate=True, no_store=True)
class mentorLogin(APIView):
    def post(self, request, format=None):
        serializer = mentorRegSerializer(data=request.data)
        if serializer.is_valid(): 
            userData = mentorRegTable.objects.filter(email=request.data['email'],password=request.data['password']).values('email')
            if userData:
                return JsonResponse({'status': 'success'})
            else:
                return JsonResponse({'status': 'error'})
        return JsonResponse({'status': 'error'})

def mentorDashboard(request):
    return render(request,'mentorDashboard.html')

def mentLoginHtml(request):
    return render(request,'loginMentor.html')


class getUserQryDataClass(APIView):
    def get(self, request, format=None):
        mentorQryData = mentorQueriesTable.objects.all()
        serializer = userQuerySerializer(mentorQryData, many=True)
        return Response(serializer.data)


@csrf_exempt
def getUserQryDataClassById(request):
    a = request.body.decode('utf-8')
    body = json.loads(a)
    mentorQryData = mentorQueriesTable.objects.filter(mQueriesTableId=body['qryId']).values()
    print(mentorQryData)
    return JsonResponse({'status': 'success','mentorQryData':list(mentorQryData)})

@csrf_exempt
def sendMsgTouser(request):
    a = request.body.decode('utf-8')
    body = json.loads(a)
    # mentorQueriesTable.objects.filter(mQueriesTableId=lastmQueriesTableId['mQueriesTableId']).update(userId=userEmail)
    userSchema=Schema.objects.filter(schemaCompanyName=body['userEmail']).values('schema_name')
    print(userSchema)
    userSchemaName=userSchema[0]['schema_name']
    connection.set_schema(schema_name=userSchemaName)
    notification(userId=body['userEmail'],mentorId=body['metEmail'],desc='Mentor send the Message',type='MSM',href=body['message']).save()
    mentorMessages(messages=body['message']).save()
    return JsonResponse({'status': 'success'})


@csrf_exempt
def UserNotificationShow(request):
    a = request.body.decode('utf-8')
    body = json.loads(a)
    userSchema=Schema.objects.filter(schemaCompanyName=body['userEmail']).values('schema_name')
    userSchemaName=userSchema[0]['schema_name']
    connection.set_schema(schema_name=userSchemaName)
    checkall=notification.objects.filter().values('notificationId','userId','mentorId','desc','type','href','viewed','status')
    return JsonResponse({'status': 'success','checkall':list(checkall)})


@csrf_exempt
def MentorNotificationShow(request):
    a = request.body.decode('utf-8')
    body = json.loads(a)
    mentorId=mentorRegTable.objects.filter(email=body['metEmail']).values('mentorId')
    checkall=mentorNotification.objects.filter(mentorId=mentorId[0]['mentorId']).values('mNotificationId','userId','mentorId','desc','type','href','viewed','status')
    return JsonResponse({'status': 'success','checkall':list(checkall)})