
function getpatientNotificationData()
{
     // var sesstionCheck=$('#sesstionCheck').val();
     // var data={'doctorId':sesstionCheck}
     var userEmail=sessionStorage.getItem('userEmail');
     console.log('validatioin');
     console.log(userEmail);
     var data={'userEmail':userEmail};
     $.ajax({
                 url: "/UserNotificationShow/",
                 type: "POST",
                 dataType : "json",
                 contentType : "application/json",
                 data: JSON.stringify(data),
                 success: function (result)
                 {
                 console.log(result);
                 $('.patientNotificationBar').empty()
                 $.each(result['checkall'][0], function (index, val) {
                    //  console.log(val.type);
                    //  alert(val.type);
                     if(val.type=='MSM')
                     {
                        $('.patientNotificationBar').append('<li class="notification-message"><a class="viewDoctorConfirmBookingnotifi" href="#" data-toggle="modal" data-target=".doctorConfirmationModal" notifiId="'+ val.notificationId +'" patientId="'+val.sendFromPatientId+'" doctorId="'+val.recivedDoctorId+'"><div class="media"><span class="avatar avatar-sm"></span><div class="media-body"><p class="noti-details"><span class="noti-title" style="display:block;"> Doctor '+ val.doctorName +' '+val.desc+'</span></p><p class="noti-time"><span class="notification-time">4 mins ago</span></p></div></div></a></li>')
                     }
                     else{
                        $('.patientNotificationBar').append('<li class="notification-message"><a class="viewDoctorConfirmBookingnotifi" href="#" data-toggle="modal" data-target=".doctorConfirmationModal" notifiId="'+ val.notificationId +'" patientId="'+val.sendFromPatientId+'" doctorId="'+val.recivedDoctorId+'"><div class="media"><span class="avatar avatar-sm"></span><div class="media-body"><p class="noti-details"><span class="noti-title" style="display:block;"> Doctor '+ val.doctorName +' '+val.desc+'</span></p><p class="noti-time"><span class="notification-time">4 mins ago</span></p></div></div></a></li>')

                     }
                 });
             
                 }
     });


}


    setInterval(getpatientNotificationData,10000);

$(document).on('click','.viewDoctorConfirmBookingnotifi',function(){
    // alert('tsdf');
    // $('.noti-details').click(function(){
        var notifiid=$(this).attr('notifiid');
        var patientid =$(this).attr('patientid');
        var doctorid=$(this).attr('doctorid'); 

        console.log(notifiid);
        console.log(patientid);
        console.log(doctorid);

        var data={'notifiid':notifiid,'patientid':patientid,'doctorid':doctorid};
        // $('.patientbookingModal').modal('show');

        $.ajax({
                        url: "/viewPatientSideAndDoctorDetailsNoti/",
                        type: "POST",
                        dataType : "json",
                        contentType : "application/json",
                        data: JSON.stringify(data),
                        success: function (result)
                        {
                        console.log(result);

                        $('#doctorName').val(result['doctorDetails'][0]['name']);
                        $('#bookingDate').val(result['appoiDetails'][0]['appointmentTakenDate']);
                        $('#doctorEmail').val(result['doctorDetails'][0]['email']);
                        $('#bookingTime').val(result['appoiDetails'][0]['appoStartTime']);

                        // $('.notifiid').val(notifiid);
                        // $('.patientid').val(patientid);
                        // $('.doctorid').val(doctorid);

                        // $('.doctorName').val(result['doctorDetails'][0]['name']);
                        // $('.doctorEmail').val(result['doctorDetails'][0]['email']);

                        // $('.notification-list').empty()
                        // $.each(result['checkall'], function (index, val) {
                        //     // console.log(val);
                        //     if(val.type=='PRD')
                        //     {
                        //         $('.notification-list').append('<li class="notification-message"><a href="#" data-toggle="modal" data-target=".patientbookingModal" notifiId="'+ val.notificationId +'" patientId="'+val.sendFromPatientId+'" doctorId="'+val.recivedDoctorId+'"><div class="media"><span class="avatar avatar-sm"><img class="avatar-img rounded-circle" alt="User Image" src="assets/img/doctors/doctor-thumb-01.jpg"></span><div class="media-body"><p class="noti-details"><span class="noti-title">'+val.desc+'</span> Schedule <span class="noti-title">her appointment</span></p><p class="noti-time"><span class="notification-time">4 mins ago</span></p></div></div></a></li>')
                        //     }
                        // });
                        }

                });

       });


$(document).on('click','.viewDoctorResBookingnotifi',function(){
    // alert('tsdf');
    // $('.noti-details').click(function(){
        var notifiid=$(this).attr('notifiid');
        var patientid =$(this).attr('patientid');
        var doctorid=$(this).attr('doctorid'); 

        console.log(notifiid);
        console.log(patientid);
        console.log(doctorid);

      $('.patientidr').val(patientid);
      $('.notifiidr').val(notifiid);
      $('.doctoridr').val(doctorid);
        
        
        

        var data={'notifiid':notifiid,'patientid':patientid,'doctorid':doctorid};
        // $('.patientbookingModal').modal('show');

        $.ajax({
                        url: "/viewPatientSideAndDoctorDetailsNoti/",
                        type: "POST",
                        dataType : "json",
                        contentType : "application/json",
                        data: JSON.stringify(data),
                        success: function (result)
                        {
                        console.log(result);

                        $('#doctorNamer').val(result['doctorDetails'][0]['name']);
                        $('#bookingDater').val(result['appoiDetails'][0]['appointmentTakenDate']);
                        $('#doctorEmailr').val(result['doctorDetails'][0]['email']);
                        $('#bookingTimer').val(result['appoiDetails'][0]['appoStartTime']);
                        $('.doctorAppoid').val(result['appoiDetails'][0]['doctorAppoId']);
                        $('.patientAppoid').val(result['appoiDetails'][0]['appointmentId']);

                        // $('.notifiid').val(notifiid);
                        // $('.patientid').val(patientid);
                        // $('.doctorid').val(doctorid);

                        // $('.doctorName').val(result['doctorDetails'][0]['name']);
                        // $('.doctorEmail').val(result['doctorDetails'][0]['email']);

                        // $('.notification-list').empty()
                        // $.each(result['checkall'], function (index, val) {
                        //     // console.log(val);
                        //     if(val.type=='PRD')
                        //     {
                        //         $('.notification-list').append('<li class="notification-message"><a href="#" data-toggle="modal" data-target=".patientbookingModal" notifiId="'+ val.notificationId +'" patientId="'+val.sendFromPatientId+'" doctorId="'+val.recivedDoctorId+'"><div class="media"><span class="avatar avatar-sm"><img class="avatar-img rounded-circle" alt="User Image" src="assets/img/doctors/doctor-thumb-01.jpg"></span><div class="media-body"><p class="noti-details"><span class="noti-title">'+val.desc+'</span> Schedule <span class="noti-title">her appointment</span></p><p class="noti-time"><span class="notification-time">4 mins ago</span></p></div></div></a></li>')
                        //     }
                        // });
                        }

                });

       });



$(document).on('click','.patientConfirmRes',function(){
   var patientidr=$('.patientidr').val();
   var notifiidr=$('.notifiidr').val();
   var doctoridr=$('.doctoridr').val();
   var doctorAppoid=$('.doctorAppoid').val();
   var patientAppoid=$('.patientAppoid').val();

   var data={'patientidr':patientidr,'notifiidr':notifiidr,'doctoridr':doctoridr,'doctorAppoid':doctorAppoid,'patientAppoid':patientAppoid};


   $.ajax({
         url: "/patientCondoctorRes/",
         type: "POST",
         dataType : "json",
         contentType : "application/json",
         data: JSON.stringify(data),
         success: function (result)
         {
            console.log(result);
            swal({
                  title: "Alert!",
                  text: 'Appoinment successfully confirmed  ! ',
                  type: "success"
                  });

         }

   });

});




function showPatientNotificationDataDash()
{
     // var sesstionCheck=$('#sesstionCheck').val();
     // var data={'doctorId':sesstionCheck}
     var pateintLoginCheck=sessionStorage.getItem('loginPatientEmailSession');
     console.log('validatioin');
     console.log(pateintLoginCheck);
     var data={'pateintLoginCheck':pateintLoginCheck};
     $.ajax({
                 url: "/patientNotificationShow/",
                 type: "POST",
                 dataType : "json",
                 contentType : "application/json",
                 data: JSON.stringify(data),
                 success: function (result)
                 {
                 console.log(result);
               //   $('.patientNotificationBar').empty()
               $('.notification-list').empty()
                 $.each(result['pNoData'][0], function (index, val) {
                    //  console.log(val.type);
                    //  alert(val.type);
                     if(val.type=='DCB')
                     {
                        $('.notification-list').append('<li class="notification-message"><a class="viewDoctorConfirmBookingnotifi" href="#" data-toggle="modal" data-target=".doctorConfirmationModal" notifiId="'+ val.notificationId +'" patientId="'+val.sendFromPatientId+'" doctorId="'+val.recivedDoctorId+'"><div class="media"><div class="media-body"><p class="noti-details"><span class="noti-title">' + val.doctorName +' '+ val.desc+'</span> Schedule <span class="noti-title">her appointment</span></p><p class="noti-time"><span class="notification-time">4 mins ago</span></p></div></div></a></li>');
                        // $('.patientNotificationBar').append('<li class="notification-message"><a class="viewDoctorConfirmBookingnotifi" href="#" data-toggle="modal" data-target=".doctorConfirmationModal" notifiId="'+ val.notificationId +'" patientId="'+val.sendFromPatientId+'" doctorId="'+val.recivedDoctorId+'"><div class="media"><span class="avatar avatar-sm"></span><div class="media-body"><p class="noti-details"><span class="noti-title" style="display:block;"> Doctor '+ val.doctorName +' '+val.desc+'</span></p><p class="noti-time"><span class="notification-time">4 mins ago</span></p></div></div></a></li>')
                     }
                     else if(val.type=='DRB')
                     {
                        //  console.log('DRB');
                        $('.notification-list').append('<li class="notification-message"><a class="viewDoctorResBookingnotifi" href="#" data-toggle="modal" data-target=".patientConfirmationModal" notifiId="'+ val.notificationId +'" patientId="'+val.sendFromPatientId+'" doctorId="'+val.recivedDoctorId+'"><div class="media"><div class="media-body"><p class="noti-details"><span class="noti-title">' + val.doctorName +' '+ val.desc+'</span> Schedule <span class="noti-title">her appointment</span></p><p class="noti-time"><span class="notification-time">4 mins ago</span></p></div></div></a></li>');
                        // $('.patientNotificationBar').append('<li class="notification-message"><a class="viewDoctorResBookingnotifi" href="#" data-toggle="modal" data-target=".patientConfirmationModal" notifiId="'+ val.notificationId +'" patientId="'+val.sendFromPatientId+'" doctorId="'+val.recivedDoctorId+'"><div class="media"><span class="avatar avatar-sm"></span><div class="media-body"><p class="noti-details"><span class="noti-title" style="display:block;"> Doctor '+ val.doctorName +' '+val.desc+'</span></p><p class="noti-time"><span class="notification-time">4 mins ago</span></p></div></div></a></li>')
                     }
                     else if(val.type=='DCancelB'){
                        $('.notification-list').append('<li class="notification-message"><a class="viewDoctorConfirmBookingnotifi" href="#" data-toggle="modal" data-target=".doctorConfirmationModal" notifiId="'+ val.notificationId +'" patientId="'+val.sendFromPatientId+'" doctorId="'+val.recivedDoctorId+'"><div class="media"><div class="media-body"><p class="noti-details"><span class="noti-title">' + val.doctorName +' '+ val.desc+'</span> Schedule <span class="noti-title">her appointment</span></p><p class="noti-time"><span class="notification-time">4 mins ago</span></p></div></div></a></li>');
                        // $('.patientNotificationBar').append('<li class="notification-message"><a class="viewDoctorConfirmBookingnotifi" href="#" data-toggle="modal" data-target=".doctorConfirmationModal" notifiId="'+ val.notificationId +'" patientId="'+val.sendFromPatientId+'" doctorId="'+val.recivedDoctorId+'"><div class="media"><span class="avatar avatar-sm"></span><div class="media-body"><p class="noti-details"><span class="noti-title" style="display:block;"> Doctor '+ val.doctorName +' '+val.desc+'</span></p><p class="noti-time"><span class="notification-time">4 mins ago</span></p></div></div></a></li>')

                     }
                 });
             
                 }
     });


}


setInterval(showPatientNotificationDataDash,10000);