function validFunction(e,formClassName='',validaname='',id='') {
    var ret_val = 1;	
    if(formClassName=='')
    {
      // console.log('form name Empty');
    var chkmsgg = $('input[name="' + e + '"]').attr("valid-name");
    var chkmsg = $('input[name="' + e + '"]').attr("id");
    // console.log(chkmsg);
    }
    else{
      // console.log('form name edit form');
      // console.log(formClassName);
      // var chkmsgg = $('input[name="' + e + '"]').attr("valid-name");
      var chkmsgg = validaname;
      var chkmsg = id;
    // console.log(chkmsg);
    }
    // var name=$(this).attr("name");
    switch ($.trim(chkmsgg)) {
      case 'fullname':
          var regex = /^([A-Za-z.\s]){2,200}$/;
          if (!regex.test($.trim($('#'+chkmsg).val())) && $('#'+chkmsg).closest('.well').css('display') !== 'none' && $('#'+chkmsg).closest('.well').css(
                  'display') !== 'none') {
              ret_val *= failCall(chkmsg);
          } else {
              ret_val *= successCall(chkmsg);
          }
          break;
      case 'numb':
          var regex = /^(\+?\d{1,3}|\d{1,4})$/;
          if($('#'+chkmsg).length > 0)
          {
            if (!regex.test($.trim($('#'+chkmsg).val()))) {
              // console.log('fales');
                ret_val *= failCall(chkmsg);
            } else {
                ret_val *= successCall(chkmsg);
            } 
          }
          else
          {
            // console.log('fales two');
            ret_val *= failCall(chkmsg);
          }			
          break;
      case 'password':
          var regex =  /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[0-9a-zA-Z]{8,}$/;
          if($('#'+chkmsg).length > 0)
          {
            if (!regex.test($.trim($('#'+chkmsg).val()))) {
              // console.log('fales');
                ret_val *= failCall(chkmsg);
            } else {
                ret_val *= successCall(chkmsg);
            } 
          }
          else
          {
            // console.log('fales two');
            ret_val *= failCall(chkmsg);
          }			
          break;
      case 'mobile':
          var regex = /^[6789]\d{9}$/;
          if($('#'+chkmsg).val().length > 0)
          {
            if (!regex.test($.trim($('#'+chkmsg).val()))) {
                ret_val *= failCall(chkmsg);
            } else {
              ret_val *= successCall(chkmsg);
            }
          }
          else
          {
            ret_val *= failCall(chkmsg);
          }
          break;
      case 'required':
          if ($('#'+chkmsg).val() !='') {
            // console.log('true');
                 ret_val *= successCall(chkmsg);
          } else {
            // console.log('false req');
              ret_val *= failCall(chkmsg);
          }
          break;
      case 'email':
          var regex = /^[_a-z0-9A-Z-]+(\.[_a-z0-9A-Z-]+)*@([a-z0-9A-Z-]{3,100})+(\.[a-z0-9A-Z-]+)*(\.[a-zA-Z-]{2,4})$/;
          if($('#'+chkmsg).val().length > 0)
          {
            if (!regex.test($.trim($('#'+chkmsg).val())) ) {
                ret_val *= failCall(chkmsg);
            } else {
              ret_val *= successCall(chkmsg);
            }
          }
          else
          {
            ret_val *= failCall(chkmsg);
          }
          break;
      case 'select':
          if ($('#'+chkmsg).find('option:selected').val() == '' || typeof($('#'+chkmsg).find("option:selected")) == 'undefined' || $('#'+chkmsg).find('option:selected').val() == 'undefined') {
            // console.log('drop false one');
                        ret_val *= failCall(chkmsg);
          } else {
              if ($('#'+chkmsg).find('option:selected').val() != '' && typeof($('#'+chkmsg).find("option:selected")) != 'undefined' && $('#'+chkmsg).find('option:selected').val() != 'undefined') {
                // console.log('drop false two');
                ret_val *= successCall(chkmsg);
              }
              else {
                // console.log('drop true');
                 ret_val *= failCall(chkmsg);
              }
            }
          break;
      default:
        break;
  }
  return ret_val;  
  }


function successCall(chkmsg) {
  if($('#'+chkmsg).attr('id')=='sdate' || $('#'+chkmsg).attr('valid-name')=='radio')
  {
      $('#'+chkmsg).parent().siblings(".agree").children('span').removeClass('show');
      $('#'+chkmsg).parent().siblings(".agree").children('span').addClass('hide');
  }
  else
  {
      $('#'+chkmsg).siblings(".agree").children('span').attr("class","hide");
      $('#'+chkmsg).siblings(".agree").children('span').removeClass("show");		
  }
  return 1;
}

function failCall(chkmsg) {
$('#'+chkmsg).siblings(".agree").children('span').removeClass('hide');
$('#'+chkmsg).siblings(".agree").children('span').addClass('show');
  return 0;
}